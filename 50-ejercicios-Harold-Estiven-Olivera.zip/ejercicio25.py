# Ejercicio 25 - Conversor binario (entero a binario)
def a_binario(n):
    return bin(n)[2:]
if __name__ == '__main__':
    print(a_binario(13))
